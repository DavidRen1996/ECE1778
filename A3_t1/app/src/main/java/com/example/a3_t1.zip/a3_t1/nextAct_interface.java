package com.example.a3_t1;

import android.content.Intent;

public interface nextAct_interface{
    Intent setup(Class c1, Class c2);
    void startnext(Intent i);
}
